
/* =========================
   HYPROCODING V2 MENU
========================= */

const sidebar = document.getElementById("sidebar");

const menuButton =
    document.getElementById("menuButton") ||
    document.querySelector(".menu-button");

const closeButton =
    document.getElementById("closeButton") ||
    document.querySelector(".close-button");

let backdrop = document.getElementById("menuBackdrop");


/* =========================
   CREATE BACKDROP IF NEEDED
========================= */

if (!backdrop && sidebar) {
    backdrop = document.createElement("div");
    backdrop.id = "menuBackdrop";
    backdrop.className = "menu-backdrop";
    document.body.appendChild(backdrop);
}


/* =========================
   KEEP MENU CONSISTENT
========================= */

if (sidebar) {
    const navigation = sidebar.querySelector(".navigation");

    if (navigation) {
        const isDashboard =
            window.location.pathname.endsWith("/") ||
            window.location.pathname.endsWith("index.html");

        const dashboardLink = isDashboard
            ? "index.html"
            : "index.html";

        const aboutLink = isDashboard
            ? "#about"
            : "index.html#about";

        navigation.innerHTML = `
            <a href="${dashboardLink}" class="nav-link">
                <span class="nav-icon">⌂</span>
                <span>Dashboard</span>
            </a>

            <a href="${aboutLink}" class="nav-link">
                <span class="nav-icon">ⓘ</span>
                <span>About HYPROCODING</span>
            </a>
        `;

        // Highlight the current page or section.
        const currentPath = window.location.pathname;

        navigation.querySelectorAll(".nav-link").forEach(link => {
            link.classList.remove("active");

            const href = link.getAttribute("href");

            if (
                (href === "index.html" &&
                    (currentPath.endsWith("/") ||
                     currentPath.endsWith("index.html"))) ||
                (href === "#about" &&
                    window.location.hash === "#about")
            ) {
                link.classList.add("active");
            }
        });

        // Close the menu after selecting a navigation link.
        navigation.addEventListener("click", function (event) {
            const link = event.target.closest(".nav-link");

            if (link) {
                closeMenu();
            }
        });
    }
}


/* =========================
   OPEN MENU
========================= */

function openMenu() {
    if (!sidebar) return;

    sidebar.classList.add("show");

    if (backdrop) {
        backdrop.classList.add("show");
    }

    sidebar.setAttribute("aria-hidden", "false");

    if (menuButton) {
        menuButton.setAttribute("aria-expanded", "true");
        menuButton.setAttribute("aria-label", "Close menu");
    }
}


/* =========================
   CLOSE MENU
========================= */

function closeMenu() {
    if (!sidebar) return;

    sidebar.classList.remove("show");

    if (backdrop) {
        backdrop.classList.remove("show");
    }

    sidebar.setAttribute("aria-hidden", "true");

    if (menuButton) {
        menuButton.setAttribute("aria-expanded", "false");
        menuButton.setAttribute("aria-label", "Open menu");
    }
}


/* =========================
   MENU BUTTON EVENTS
========================= */

if (menuButton) {
    menuButton.removeAttribute("onclick");

    menuButton.addEventListener("click", function () {
        if (sidebar && sidebar.classList.contains("show")) {
            closeMenu();
        } else {
            openMenu();
        }
    });
}

if (closeButton) {
    closeButton.removeAttribute("onclick");
    closeButton.addEventListener("click", closeMenu);
}

if (backdrop) {
    backdrop.addEventListener("click", closeMenu);
}


/* =========================
   CLOSE WITH ESCAPE
========================= */

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
        closeMenu();
    }
});


/* =========================
   CLICK BOUNCE ANIMATION
========================= */

function bounceButton(element) {
    if (!element) return;

    element.classList.remove("clicked");

    // Restart the animation.
    void element.offsetWidth;

    element.classList.add("clicked");

    element.addEventListener("animationend", function () {
        element.classList.remove("clicked");
    }, { once: true });
}

document.addEventListener("click", function (event) {
    const element = event.target.closest(
        "button, .course-card, .nav-link, .start-button, .lesson-button"
    );

    if (!element) return;

    bounceButton(element);
});

/* HYPROCODING FLOATING CODE PLAYGROUND */
(function () {
    function initHPPlayground() {
        if (document.getElementById("hpPlaygroundButton")) return;

        const button = document.createElement("button");
        button.id = "hpPlaygroundButton";
        button.type = "button";
        button.textContent = "</>";
        button.title = "Open Code Playground";
        button.setAttribute("aria-label", "Open Code Playground");
        button.setAttribute("aria-controls", "hpPlaygroundPanel");
        button.setAttribute("aria-expanded", "false");

        const panel = document.createElement("section");
        panel.id = "hpPlaygroundPanel";
        panel.setAttribute("role", "dialog");
        panel.setAttribute("aria-label", "Interactive Code Playground");

        panel.innerHTML = `
            <div class="hp-playground-header">
                <div>
                    <div class="hp-playground-title">HYPROCODING PLAYGROUND</div>
                    <div class="hp-playground-subtitle">
                        Write code. Run it. See the result.
                    </div>
                </div>
                <button type="button" class="hp-playground-close"
                    id="hpPlaygroundClose" aria-label="Close playground">&times;</button>
            </div>

            <div class="hp-playground-toolbar">
                <button type="button" class="hp-playground-tab hp-active"
                    data-hp-tab="html">HTML</button>
                <button type="button" class="hp-playground-tab"
                    data-hp-tab="css">CSS</button>
                <button type="button" class="hp-playground-action hp-run"
                    id="hpPlaygroundRun">▶ Run</button>
                <button type="button" class="hp-playground-action"
                    id="hpPlaygroundReset">Reset</button>
            </div>

            <div class="hp-playground-workspace">
                <div class="hp-playground-editor">
                    <div class="hp-playground-pane-title" id="hpEditorTitle">
                        HTML EDITOR
                    </div>
                    <textarea id="hpPlaygroundCode"
                        spellcheck="false"
                        autocapitalize="off"
                        autocomplete="off"
                        aria-label="Code editor"></textarea>
                </div>

                <div class="hp-playground-preview">
                    <div class="hp-playground-pane-title">LIVE PREVIEW</div>
                    <iframe id="hpPlaygroundPreview"
                        title="Code preview"
                        sandbox=""
                        referrerpolicy="no-referrer"></iframe>
                </div>
            </div>

            <div class="hp-playground-status" id="hpPlaygroundStatus"
                aria-live="polite">Ready to code.</div>
        `;

        document.body.appendChild(button);
        document.body.appendChild(panel);

        const editor = document.getElementById("hpPlaygroundCode");
        const preview = document.getElementById("hpPlaygroundPreview");
        const editorTitle = document.getElementById("hpEditorTitle");
        const status = document.getElementById("hpPlaygroundStatus");
        const tabs = panel.querySelectorAll("[data-hp-tab]");

        const starterHTML = `<div class="card">
  <h1>Hello, coder!</h1>
  <p>Welcome to HYPROCODING.</p>
  <button>Click me</button>
</div>`;

        const starterCSS = `body {
  font-family: Arial, sans-serif;
  padding: 24px;
  background: #f0f2ff;
}

.card {
  padding: 24px;
  border-radius: 16px;
  background: white;
  box-shadow: 0 8px 25px #0002;
}

h1 {
  color: #6558d9;
}

button {
  padding: 10px 16px;
  color: white;
  background: #6558d9;
  border: 0;
  border-radius: 8px;
}`;

        let htmlCode = starterHTML;
        let cssCode = starterCSS;
        let activeTab = "html";

        function updateEditor() {
            editor.value = activeTab === "html" ? htmlCode : cssCode;
            editorTitle.textContent =
                activeTab === "html" ? "HTML EDITOR" : "CSS EDITOR";

            tabs.forEach(function (tab) {
                const active = tab.dataset.hpTab === activeTab;
                tab.classList.toggle("hp-active", active);
                tab.setAttribute("aria-pressed", String(active));
            });
        }

        function saveCurrentCode() {
            if (activeTab === "html") {
                htmlCode = editor.value;
            } else {
                cssCode = editor.value;
            }
        }

        function runCode() {
            saveCurrentCode();

            const safeCSS = cssCode.replace(/<\/style/gi, "<\\/style");
            const output =
                "<!DOCTYPE html><html><head><meta charset='UTF-8'>" +
                "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>" + safeCSS + "</style></head><body>" +
                htmlCode + "</body></html>";

            preview.srcdoc = output;
            status.textContent = "Preview updated successfully.";
        }

        function openPlayground() {
            panel.classList.add("hp-visible");
            button.setAttribute("aria-expanded", "true");
            runCode();
        }

        function closePlayground() {
            saveCurrentCode();
            panel.classList.remove("hp-visible");
            button.setAttribute("aria-expanded", "false");
        }

        button.addEventListener("click", function () {
            if (panel.classList.contains("hp-visible")) {
                closePlayground();
            } else {
                openPlayground();
            }
        });

        document.getElementById("hpPlaygroundClose")
            .addEventListener("click", closePlayground);

        tabs.forEach(function (tab) {
            tab.addEventListener("click", function () {
                saveCurrentCode();
                activeTab = tab.dataset.hpTab;
                updateEditor();
            });
        });

        editor.addEventListener("input", function () {
            saveCurrentCode();
            status.textContent = "Code changed. Tap Run to update preview.";
        });

        editor.addEventListener("keydown", function (event) {
            if (event.key === "Tab") {
                event.preventDefault();

                const start = editor.selectionStart;
                const end = editor.selectionEnd;

                editor.setRangeText("  ", start, end, "end");
                saveCurrentCode();
            }

            if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
                event.preventDefault();
                runCode();
            }
        });

        document.getElementById("hpPlaygroundRun")
            .addEventListener("click", runCode);

        document.getElementById("hpPlaygroundReset")
            .addEventListener("click", function () {
                htmlCode = starterHTML;
                cssCode = starterCSS;
                activeTab = "html";
                updateEditor();
                runCode();
                status.textContent = "Starter code restored.";
            });

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" &&
                panel.classList.contains("hp-visible")) {
                closePlayground();
            }
        });

        updateEditor();
        runCode();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initHPPlayground);
    } else {
        initHPPlayground();
    }
})();
document.querySelectorAll(".nav-link").forEach(link => {
  link.addEventListener("click", function () {
    document.querySelectorAll(".nav-link").forEach(item => {
      item.classList.remove("active");
    });

    this.classList.add("active");
  });
});